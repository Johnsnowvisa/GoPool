<?php
require_once '../classes/DbConnector.php';
require_once '../classes/User.php';

use classes\User;

session_start();
error_reporting(0);
try {
  
    $dbConnector = new \classes\DbConnector();
    
  
    $dbh = $dbConnector->getConnection();
} catch (PDOException $e) {

    echo "Error: " . $e->getMessage();
}
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
if(isset($_GET['del']))
{
$id=$_GET['del'];
$sql = "delete from tblbrands  WHERE id=:id";
$query = $dbh->prepare($sql);
$query -> bindParam(':id',$id, PDO::PARAM_STR);
$query -> execute();
$msg="Page data updated  successfully";

}



 ?>
<!DOCTYPE html>
<html lang="en" class="no-js">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="theme-color" content="#3e454c">

    <title>Car Rental Portal | Admin Manage testimonials </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <!-- Font awesome -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- Sandstone Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Bootstrap Datatables -->
    <link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
    <!-- Bootstrap social button library -->
    <link rel="stylesheet" href="css/bootstrap-social.css">
    <!-- Bootstrap select -->
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <!-- Bootstrap file input -->
    <link rel="stylesheet" href="css/fileinput.min.css">
    <!-- Awesome Bootstrap checkbox -->
    <link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
    <!-- Admin Stye -->
    <link rel="stylesheet" href="css/style.css">
    <style>
          
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		
/* The Modal (background) */
.modal_img{
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  margin: auto;
  display: block;
  width: 80%; /* Default width */
  max-width: 300px; /* Max width */
  border-radius: 8px; /* Rounded corners */
  background-color: white; /* White background */
  padding: 20px; /* Padding inside the modal */
  box-shadow: 0 5px 15px rgba(0,0,0,0.3); /* Shadow for the modal */
}

/* The Close Button */
.close {
  color: red;
  float: right;
  font-size: 30px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}

.modal-image {
  width: 100%; /* Image width to fit the modal */
  border-radius: 8px;
  transition: transform 0.25s ease; /* Smooth zoom effect */
  cursor: zoom-in;
}

/* Zoomed image */
.modal-image.zoomed {
  cursor: zoom-out;
  transform: scale(2); /* Zoom level */
}
</style>

    
</head>

<body>
    <?php include('includes/header.php');?>

    <div class="ts-main-content">
        <?php include('includes/leftbar.php');?>
        <div class="content-wrapper">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-12">

                        <h2 class="page-title">Registered Users</h2>

                        <!-- Zero Configuration Table -->
                        <div class="panel panel-default">
                            <div class="panel-heading">Reg Users</div>
                            <div class="panel-body">
                                <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
                                <table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Contact no</th>
                                            <th>DOB</th>
                                            <th>Address</th>
                                            <th>Selfie Image</th>
                                            <th>NIC Image</th>
                                            <th>Status</th>
                                            <th>Reg Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
$User = new User($dbh);
$users = $User->getAllUsers();

if ($users) {
    $cnt = 1;
    foreach ($users as $result) {
        ?>
                                        <tr>
                                            <td><?php echo htmlentities($cnt); ?></td>
                                            <td><?php echo htmlentities($result->FullName); ?></td>
                                            <td><?php echo htmlentities($result->EmailId); ?></td>
                                            <td><?php echo htmlentities($result->ContactNo); ?></td>
                                            <td><?php echo htmlentities($result->DOB); ?></td>
                                            <td><?php echo htmlentities($result->Address); ?></td>
                                            <td>
                                                <img src="img/Users/<?php echo htmlentities($result->Selfie); ?>" width="50" height="50" style="border:solid 1px #000" onclick="openModal('<?php echo htmlentities($result->Selfie); ?>')">
                                            </td>
                                            <td>
                                                <img src="img/Users/<?php echo htmlentities($result->NIC); ?>" width="50" height="50" style="border:solid 1px #000" onclick="openModal('<?php echo htmlentities($result->NIC); ?>')">
                                            </td>
                                            <td id="status-<?php echo htmlentities($result->id); ?>">
                                                            <?php echo htmlentities($result->Status); ?>
                                                            <?php if ($result->Status != "Confirmed") { ?>
                                                                <button class="btn btn-primary" onclick="updateStatus(<?php echo htmlentities($result->id); ?>)">Change Status</button>
                                                            <?php } ?>
                                                        </td>
                                            <td><?php echo htmlentities($result->RegDate); ?></td>
                                        </tr>
                                        <?php
        $cnt++;
    }
} else {
    echo "No users found.";
}
?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="myModal" class="modal_img">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <img id="modalImg" class="modal-image">
        </div>
    </div>
    <!-- Loading Scripts -->
    <script src="js/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="js/bootstrap-select.min.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap.min.js"></script>
    <script src="js/Chart.min.js"></script>
    <script src="js/fileinput.js"></script>
    <script src="js/chartData.js"></script>
    <script src="js/main.js"></script>
        
            <!-- Modal HTML -->
    <div id="confirmationModal" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">User Confirmation</h4>
          </div>
          <div class="modal-body">
            <p>Do you want to accept or reject this user?</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-success" id="acceptBtn">Accept</button>
            <button type="button" class="btn btn-danger" id="rejectBtn">Reject</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
          </div>
        </div>
      </div>
    </div>

    <script>
    let selectedUserId;

    function updateStatus(userId) {
      selectedUserId = userId;
      $('#confirmationModal').modal('show');
    }

    document.getElementById("acceptBtn").addEventListener("click", function() {
      handleUserAction('confirm');
    });

    document.getElementById("rejectBtn").addEventListener("click", function() {
      handleUserAction('delete');
    });

    function handleUserAction(action) {
      var xhr = new XMLHttpRequest();
      xhr.open("POST", "update_status.php", true);
      xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
          $('#confirmationModal').modal('hide');
          if (xhr.responseText === "success") {
            document.getElementById(`status-${selectedUserId}`).innerText = "Confirmed";
          } else if (xhr.responseText === "deleted") {
            document.getElementById(`row-${selectedUserId}`).remove();
          } else {
            alert("Failed to update status. Please try again.");
          }
        }
      };
      xhr.send(`userId=${selectedUserId}&action=${action}`);
    }
    
function openModal(imageSrc) {
  var modal = document.getElementById("myModal");
  var modalImg = document.getElementById("modalImg");
  modal.style.display = "block";
  modalImg.src = "img/Users/" + imageSrc;
}

function closeModal() {
  var modal = document.getElementById("myModal");
  modal.style.display = "none";
}

document.getElementById("modalImg").addEventListener("click", function() {
  this.classList.toggle("zoomed");
});

    </script>
</body>
</html>
<?php } ?>
