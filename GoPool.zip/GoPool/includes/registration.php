<?php
//error_reporting(0);
if(isset($_POST['signup']))
  {

    $fullname = htmlspecialchars($_POST['fullname']);
    $email = htmlspecialchars($_POST['emailid']);
    $mobile = htmlspecialchars($_POST['mobileno']);
    $password=md5($_POST['password']); 
    $address = htmlspecialchars($_POST['address']);
    $dob = htmlspecialchars($_POST['dob']);
    $nicImagePath=$_FILES["nic_image"]["name"];
    $selfieImagePath=$_FILES["selfie_image"]["name"];
 
    move_uploaded_file($_FILES["nic_image"]["tmp_name"],"../admin/img/Users/".$_FILES["nic_image"]["name"]);
    move_uploaded_file($_FILES["selfie_image"]["tmp_name"],"../admin/img/Users/".$_FILES["selfie_image"]["name"]);



$sql="INSERT INTO  tblusers(FullName, EmailId, Password, ContactNo, DOB, Address, Selfie, NIC) VALUES(:fullname, :email, :password, :contactno, :dob, :address, :selfie_image, :nic_image)";
$stmt = $dbh->prepare($sql);
         $stmt->bindParam(':fullname', $fullname,PDO::PARAM_STR);
        $stmt->bindParam(':email', $email,PDO::PARAM_STR);
        $stmt->bindParam(':password', $password,PDO::PARAM_STR);
        $stmt->bindParam(':contactno', $mobile,PDO::PARAM_STR); 
        $stmt->bindParam(':dob', $dob,PDO::PARAM_STR);
        $stmt->bindParam(':address', $address,PDO::PARAM_STR);
        $stmt->bindParam(':selfie_image', $selfieImagePath,PDO::PARAM_STR);
        $stmt->bindParam(':nic_image', $nicImagePath,PDO::PARAM_STR);
        $stmt->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
echo "<script>alert('Registration successfull. Wait For Admin Verfication');</script>";
}
else 
{
echo "<script>alert('Something Went Wrong. Please Try Again');</script>";
}
}

?>


<script>
function checkAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'emailid='+$("#emailid").val(),
type: "POST",
success:function(data){
$("#user-availability-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>
<script type="text/javascript">
document.addEventListener('DOMContentLoaded', (event) => {
    var password = document.forms["signup"]["password"];
    var confirmPassword = document.forms["signup"]["confirmpassword"];
    
    confirmPassword.addEventListener('input', function() {
        if (password.value !== confirmPassword.value) {
            confirmPassword.setCustomValidity("Passwords do not match. Try again.");
        } else {
            confirmPassword.setCustomValidity("");
        }
    });
});
</script>
 <style>
        .modal-body {
            max-height: 70vh; 
            overflow-y: auto;
            overflow-x: hidden;
        }
    </style>
<div class="modal fade" id="signupform">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title">Sign Up</h3>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="signup_wrap">
            <div class="col-md-12 col-sm-6">
              <form  method="post" name="signup" onSubmit="return valid();">
                <div class="form-group">
                  <input type="text" class="form-control" name="fullname" placeholder="Full Name" required="required">
                </div>
                  
                      <div class="form-group">
                  <input type="text" class="form-control" name="mobileno" placeholder="Mobile Number" maxlength="10" required="required">
                </div>
                <div class="form-group">
                  <input type="email" class="form-control" name="emailid" id="emailid" onBlur="checkAvailability()" placeholder="Email Address" required="required">
                   <span id="user-availability-status" style="font-size:12px;"></span> 
                </div>
                  <div class="form-group">
                                    <input type="date" class="form-control" name="dob" id="dob" placeholder="Date Of Birth" required="required">
                                </div>
                   <div class="form-group">
                  <input type="text" class="form-control" name="address" placeholder="Address" maxlength="70" required="required">
                </div>
                <div class="form-group">
                  <input type="password" class="form-control" name="password" placeholder="Password" required="required">
                </div>
                <div class="form-group">
                  <input type="password" class="form-control" name="confirmpassword" placeholder="Confirm Password" required="required">
                </div>
                 <div class="form-group">
                      <label>Upload Your Front Of NIC</label>
                      <input type="file" name="nic_image" required="required">
                 </div>
               <div class="form-group">
                      <label>Upload Your Selfie Image</label>
                      <input type="file"  name="selfie_image" required="required">
                  </div>
                <div class="form-group checkbox">
                  <input type="checkbox" id="terms_agree" required="required" checked="">
                  <label for="terms_agree">I Agree with <a href="page.php?type=terms">Terms and Conditions</a></label>
                </div>
                <div class="form-group">
                  <input type="submit" value="Sign Up" name="signup" id="submit" class="btn btn-block">
                </div>
              </form>
            </div>
            
          </div>
        </div>
      </div>
      <div class="modal-footer text-center">
        <p>Already got an account? <a href="#loginform" data-toggle="modal" data-dismiss="modal">Login Here</a></p>
      </div>
    </div>
  </div>
</div>