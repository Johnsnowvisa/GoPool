<?php

include '../classes/DbConnector.php'; 
include '../classes/User.php';

use classes\User;

try {
    $dbConnector = new \classes\DbConnector();
    $dbh = $dbConnector->getConnection();
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}

if(isset($_POST['signup']))
  {

     $fullname = htmlspecialchars($_POST['fullname']);
    $email = htmlspecialchars($_POST['emailid']);
    $mobile = htmlspecialchars($_POST['mobileno']);
    $password = $_POST['password'];
    $address = htmlspecialchars($_POST['address']);
    $dob = htmlspecialchars($_POST['dob']);
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
    $nicImagePath=$_FILES["nic_image"]["name"];
    $selfieImagePath=$_FILES["selfie_image"]["name"];
    
    
    echo  "<script>alert('Hello' .$fullname);</script>";
   
    
//   move_uploaded_file($_FILES["nic_image"]["tmp_name"],"../admin/img/Users/".$_FILES["nic_image"]["name"]);
//   ove_uploaded_file($_FILES["selfie_image"]["tmp_name"],"../admin/img/Users/".$_FILES["selfie_image"]["name"]);
//    
//    
//
//               $user = new User($dbh);
//                if ($user->register($fullname, $email, $mobile, $hashedPassword, $address, $dob, $nicImagePath, $selfieImagePath)) {
//                    echo "<script>alert('Registration successful. Please wait for the admin to confirm.');</script>";
//                    $formSuccess = "";
//                } else {
//                    echo "<script>alert('Something went wrong. Please try again');</script>";
//                } 
//    
  }             
            
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        .modal-body {
            max-height: 70vh; 
            overflow-y: auto;
            overflow-x: hidden;
        }
    </style>
</head>
<body>
<script>
function checkAvailability() {
    $("#loaderIcon").show();
    $.ajax({
        url: "check_availability.php",
        data: { emailid: $("#emailid").val() },
        type: "POST",
        success: function(data) {
            $("#user-availability-status").html(data);
            $("#loaderIcon").hide();
        },
        error: function() {}
    });
}

document.addEventListener('DOMContentLoaded', (event) => {
    var password = document.forms["signup"]["password"];
    var confirmPassword = document.forms["signup"]["confirmpassword"];
    
    confirmPassword.addEventListener('input', function() {
        if (password.value !== confirmPassword.value) {
            confirmPassword.setCustomValidity("Passwords do not match. Try again.");
        } else {
            confirmPassword.setCustomValidity("");
        }
    });
});
</script>

<div class="modal fade" id="signupform">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h3 class="modal-title">GoPool Sign Up</h3>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="signup_wrap">
                        <div class="col-md-12 col-sm-6">                       

                            <form method="post" action="Reg_process" enctype="multipart/form-data">
                                <div class="form-group">
                                    <input type="text" class="form-control" name="fullname" placeholder="Full Name" required="required">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="mobileno" placeholder="Mobile Number" maxlength="10" required="required">
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" name="emailid" id="emailid" onBlur="checkAvailability()" placeholder="Email Address" required="required">
                                    <span id="user-availability-status" style="font-size:10px;"></span> 
                                </div>
                                <div class="form-group">
                                    <input type="date" class="form-control" name="dob" id="dob" placeholder="Date Of Birth" required="required">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="address" placeholder="Address" maxlength="100" required="required">
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" name="password" placeholder="Password" required="required">
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" name="confirmpassword" placeholder="Confirm Password" required="required">
                                </div>
                                <div class="form-group">
                                    <label for="nic_image">Upload Your Front Of NIC</label>
                                    <input type="file" class="form-control" name="nic_image" required="required">
                                </div>
                                <div class="form-group">
                                    <label for="selfie_image">Upload Your Selfie Image</label>
                                    <input type="file" class="form-control" name="selfie_image" required="required">
                                </div>
                                <div class="form-group checkbox">
                                    <input type="checkbox" id="terms_agree" required="required" checked="">
                                    <label for="terms_agree">I Agree with <a href="page.php?type=terms">Terms and Conditions</a></label>
                                </div>
                                <div class="form-group">
                                    <input type="submit" value="Sign Up" name="signup" id="submit" class="btn btn-block">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
