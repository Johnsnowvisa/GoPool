<?php
if (isset($_POST['signup'])) {
    // Sanitize input data
    $fullname = htmlspecialchars($_POST['fullname']);
    $email = htmlspecialchars($_POST['emailid']);
    $mobile = htmlspecialchars($_POST['mobileno']);
    $password = md5($_POST['password']);
    $address = htmlspecialchars($_POST['address']);
    $dob = htmlspecialchars($_POST['dob']);

    // Define file upload paths
    $uploadDir = 'admin/img/Users/';
    $nicImageName = basename($_FILES["nic_image"]["name"]);
    $selfieImageName = basename($_FILES["selfie_image"]["name"]);
    $nicImagePath = $uploadDir . $nicImageName;
    $selfieImagePath = $uploadDir . $selfieImageName;

    // Ensure upload directory exists and is writable
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    if (!is_writable($uploadDir)) {
        chmod($uploadDir, 0755);
    }

    // Check if files were uploaded without errors
    if ($_FILES["nic_image"]["error"] === UPLOAD_ERR_OK && $_FILES["selfie_image"]["error"] === UPLOAD_ERR_OK) {
        // Attempt to move the uploaded files
        $nicUploadSuccess = move_uploaded_file($_FILES["nic_image"]["tmp_name"], $nicImagePath);
        $selfieUploadSuccess = move_uploaded_file($_FILES["selfie_image"]["tmp_name"], $selfieImagePath);

        if ($nicUploadSuccess && $selfieUploadSuccess) {
            // Prepare and execute SQL query
            $sql = "INSERT INTO tblusers (FullName, EmailId, Password, ContactNo, DOB, Address, Selfie, NIC) 
                    VALUES (:fullname, :email, :password, :contactno, :dob, :address, :selfie_image, :nic_image)";
            $stmt = $dbh->prepare($sql);
            $stmt->bindParam(':fullname', $fullname, PDO::PARAM_STR);
            $stmt->bindParam(':email', $email, PDO::PARAM_STR);
            $stmt->bindParam(':password', $password, PDO::PARAM_STR);
            $stmt->bindParam(':contactno', $mobile, PDO::PARAM_STR);
            $stmt->bindParam(':dob', $dob, PDO::PARAM_STR);
            $stmt->bindParam(':address', $address, PDO::PARAM_STR);
            $stmt->bindParam(':selfie_image', $selfieImageName, PDO::PARAM_STR); // Store only the image name
            $stmt->bindParam(':nic_image', $nicImageName, PDO::PARAM_STR); // Store only the image name
            $stmt->execute();

            $lastInsertId = $dbh->lastInsertId();
            if ($lastInsertId) {
                echo "<script>alert('Registration successful. Wait for admin verification.');</script>";
            } else {
                echo "<script>alert('Something went wrong. Please try again.');</script>";
                file_put_contents($logFile, "Database insertion failed for user: $fullname\n", FILE_APPEND);
            }
        } else {
            // Output detailed error messages
            echo "<script>alert('File upload failed. Please try again.');</script>";
            if (!$nicUploadSuccess) {
                file_put_contents($logFile, "NIC Image upload failed: " . $_FILES["nic_image"]["error"] . "\n", FILE_APPEND);
            }
            if (!$selfieUploadSuccess) {
                file_put_contents($logFile, "Selfie Image upload failed: " . $_FILES["selfie_image"]["error"] . "\n", FILE_APPEND);
            }
        }
    } else {
        // Display specific upload errors
        echo "<script>alert('File upload failed. Error code: " . $_FILES["nic_image"]["error"] . " and " . $_FILES["selfie_image"]["error"] . "');</script>";
        file_put_contents($logFile, "File upload error codes: " . $_FILES["nic_image"]["error"] . " and " . $_FILES["selfie_image"]["error"] . "\n", FILE_APPEND);
    }
}
?>    

<?php
include '../classes/DbConnector.php'; 
include '../classes/User.php';

use classes\User;

try {
    $dbConnector = new \classes\DbConnector();
    $dbh = $dbConnector->getConnection();
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}

if(isset($_POST['signup']))
  {

    $fullname = htmlspecialchars($_POST['fullname']);
    $email = htmlspecialchars($_POST['emailid']);
    $mobile = htmlspecialchars($_POST['mobileno']);
    $password = $_POST['password'];
    $address = htmlspecialchars($_POST['address']);
    $dob = htmlspecialchars($_POST['dob']);
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
    $uploadDir = 'admin/img/Users/';
    $nicImageName = basename($_FILES["nic_image"]["name"]);
    $selfieImageName = basename($_FILES["selfie_image"]["name"]);
    $nicImagePath = $uploadDir . $nicImageName;
    $selfieImagePath = $uploadDir . $selfieImageName;

//     move_uploaded_file($_FILES["nic_image"]["tmp_name"],"admin/img/Users/".$_FILES["nic_image"]["name"]);
//     move_uploaded_file($_FILES["selfie_image"]["tmp_name"],"admin/img/Users/".$_FILES["selfie_image"]["name"]);
    
    move_uploaded_file($_FILES["nic_image"]["tmp_name"], $nicImagePath);
    move_uploaded_file($_FILES["selfie_image"]["tmp_name"], $selfieImagePath);


               $user = new User($dbh);
                if ($user->register($fullname, $email, $mobile, $hashedPassword, $address, $dob, $nicImagePath, $selfieImagePath)) {
                    echo "<script>alert('Registration successful. Please wait for the admin to confirm.');</script>";
                    $formSuccess = "";
                } else {
                    echo "<script>alert('Something went wrong. Please try again');</script>";
                } 
//    
  }  
?>
