<?php
session_start();
error_reporting(0);
require_once './classes/DbConnector.php';

use classes\DbConnector;

try {
    $dbConnector = new DbConnector();
    $dbh = $dbConnector->getConnection();
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}

$rides = [];
$searchMessage = '';

$useremail = $_SESSION['login'];
$sql = "SELECT * FROM tblusers WHERE EmailId = :useremail";
$query = $dbh->prepare($sql);
$query->bindParam(':useremail', $useremail, PDO::PARAM_STR);
$query->execute();
$results = $query->fetchAll(PDO::FETCH_OBJ);
$cnt = 1;
if ($query->rowCount() > 0) {
    $postedby = $results[0]->FullName;  // Fetching the user's FullName
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search'])) {
    $from_place = $_POST['from'];
    $to_place = $_POST['to'];
    $date_of_travel = $_POST['date'] ?? null;

    // Prepare SQL query based on whether date is provided or not
    if ($date_of_travel) {
        $sql = "SELECT * FROM tblrides WHERE start_place LIKE :from_place AND end_place LIKE :to_place AND date_of_travel = :date_of_travel AND postedby <> :postedby";
        $query = $dbh->prepare($sql);
        $query->bindValue(':date_of_travel', $date_of_travel, PDO::PARAM_STR);
    } else {
        $sql = "SELECT * FROM tblrides WHERE start_place LIKE :from_place AND end_place LIKE :to_place AND postedby <> :postedby";
        $query = $dbh->prepare($sql);
    }
    $query->bindValue(':from_place', '%' . $from_place . '%', PDO::PARAM_STR);
    $query->bindValue(':to_place', '%' . $to_place . '%', PDO::PARAM_STR);
    $query->bindValue(':postedby', $postedby, PDO::PARAM_STR);  // Added binding for postedby
    $query->execute();
    $rides = $query->fetchAll(PDO::FETCH_OBJ);

    if (empty($rides)) {
        $searchMessage = "<h6 class='text-danger' style='color: red'; font-size: 16px;'>No matching rides found.</h6>";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_ride'])) {
    $ride_id = $_POST['ride_id'];

    // Fetch ride details to update available seats
    $stmt = $dbh->prepare("SELECT available_seats FROM tblrides WHERE id = :ride_id");
    $stmt->bindValue(':ride_id', $ride_id, PDO::PARAM_INT);
    $stmt->execute();
    $ride = $stmt->fetch(PDO::FETCH_OBJ);

    if ($ride && $ride->available_seats > 0) {
        // Update available seats
        $new_seat_count = $ride->available_seats - 1;
        $updateStmt = $dbh->prepare("UPDATE tblrides SET available_seats = :available_seats WHERE id = :ride_id");
        $updateStmt->bindValue(':available_seats', $new_seat_count, PDO::PARAM_INT);  // Fixed to update available_seats
        $updateStmt->bindValue(':ride_id', $ride_id, PDO::PARAM_INT);
        $updateStmt->execute();

        // Redirect to the same page to reflect the changes
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Search Rides</title>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBjouAs7Oot1Awblj7d_9TOf6dUrsBo2ow&libraries=places" async defer></script>
  <style>
    body {
      font-family: Arial, sans-serif;
      display: flex;
      height: 100vh;
      margin: 0;
      background-color: #f0f0f0;
    }
    .sidebar {
      width: 350px;
      padding: 20px;
      background-color: #fff;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
      overflow-y: auto;
    }
    .map-container {
      flex: 1;
      height: 100%;
    }
    h1 {
      font-size: 24px;
      margin-bottom: 20px;
      color: #333;
    }
    label {
      display: block;
      margin-bottom: 10px;
      font-weight: bold;
      color: #555;
    }
    input, select {
      width: 100%;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 5px;
      margin-bottom: 10px;
      box-sizing: border-box;
    }
    input:focus, select:focus {
      border-color: #007bff;
      outline: none;
      box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
    }
    .results {
      margin-top: 10px;
      padding: 10px;
      background-color: #f9f9f9;
      border: 1px solid #ddd;
      border-radius: 5px;
    }
    .form-group {
      margin-bottom: 15px;
    }
    .btn {
      display: block;
      width: 100%;
      padding: 10px;
      background-color: #007bff;
      color: #fff;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
      margin-top: 10px;
    }
    .btn:hover {
      background-color: #0056b3;
    }
    .ride-item {
      margin-bottom: 10px;
    }
    .ride-item p {
      margin: 5px 0;
    }
    .btn-container {
      display: flex;
      gap: 10px;
      margin-top: 10px;
    }
    .btn-details, .btn-request, .btn-show-more {
      flex: 1;
    }
    .btn-show-more {
      background-color: #28a745;
    }
    .btn-show-more:hover {
      background-color: #1e7e34;
    }
  </style>
  <script>
    let map;

    function initMap() {
      map = new google.maps.Map(document.getElementById('map'), {
        zoom: 12,
        center: { lat: 6.9271, lng: 79.9585 }  // Centered on Colombo, Sri Lanka
      });

      const directionsService = new google.maps.DirectionsService();
      const directionsRenderer = new google.maps.DirectionsRenderer();
      directionsRenderer.setMap(map);

      <?php if (!empty($rides)) { ?>
        <?php foreach ($rides as $ride) { ?>
          calculateAndDisplayRoute(directionsService, directionsRenderer, '<?php echo $ride->start_place; ?>', '<?php echo $ride->end_place; ?>');
        <?php } ?>
      <?php } ?>
    }

    function calculateAndDisplayRoute(directionsService, directionsRenderer, startPlace, endPlace) {
      directionsService.route(
        {
          origin: startPlace,
          destination: endPlace,
          travelMode: google.maps.TravelMode.DRIVING
        },
        function(response, status) {
          if (status === 'OK') {
            directionsRenderer.setDirections(response);
          } else {
            console.error('Directions request failed due to ' + status);
          }
        }
      );
    }

    function initAutocomplete() {
      const fromInput = document.getElementById('from');
      const toInput = document.getElementById('to');
      
      const fromAutocomplete = new google.maps.places.Autocomplete(fromInput);
      const toAutocomplete = new google.maps.places.Autocomplete(toInput);

      fromAutocomplete.addListener('place_changed', function() {
        const place = fromAutocomplete.getPlace();
        if (!place.geometry) {
          console.log("No details available for input: '" + place.name + "'");
        }
      });

      toAutocomplete.addListener('place_changed', function() {
        const place = toAutocomplete.getPlace();
        if (!place.geometry) {
          console.log("No details available for input: '" + place.name + "'");
        }
      });
    }
  </script>
</head>

<body onload="initMap(); initAutocomplete();">
  <div class="sidebar">
    <h1>Search Rides</h1>
    <?php echo $searchMessage; ?>
    <form method="POST" action="">
      <div class="form-group">
        <label for="from">From:</label>
        <input id="from" name="from" type="text" placeholder="Enter start location" required>
      </div>
      <div class="form-group">
        <label for="to">To:</label>
        <input id="to" name="to" type="text" placeholder="Enter end location" required>
      </div>
      <div class="form-group">
        <label for="date">Date:</label>
        <input id="date" name="date" type="date">
      </div>
      <button class="btn" type="submit" name="search">Search</button>
    </form>
    <div class="results">
      <h2>Matching Rides</h2>
      <?php if (!empty($rides)) { ?>
        <?php foreach ($rides as $ride) { ?>
          <div class="ride-item">
            <p><strong>From:</strong> <?php echo htmlentities($ride->start_place); ?></p>
            <p><strong>To:</strong> <?php echo htmlentities($ride->end_place); ?></p>
            <p><strong>Date:</strong> <?php echo htmlentities($ride->date_of_travel); ?></p>
            <p><strong>Available Seats:</strong> <?php echo htmlentities($ride->capacity); ?></p>
            <p><strong>Driver:</strong> <?php echo htmlentities($ride->postedby); ?></p>
            <p><strong>Message:</strong> <?php echo htmlentities($ride->message); ?></p>
            <div class="btn-container">
  <form method="POST" action="Ride_Request_Info.php">
   
    <input type="hidden" name="postedby" value="<?php echo $ride->postedby; ?>">
    <button class="btn btn-request" type="submit" name="request_ride" <?php echo $ride->capacity <= 0 ? 'disabled' : ''; ?>>
      <?php echo $ride->capacity <= 0 ? 'No Seats Available' : 'Request Ride'; ?>
    </button>
  </form>
</div>

          </div>
        <?php } ?>
      <?php } else { ?>
        <p>No rides available.</p>
      <?php } ?>
    </div>
  </div>
  <div id="map" class="map-container"></div>
</body>
</html>
