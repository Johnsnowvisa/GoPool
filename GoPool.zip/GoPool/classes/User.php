<?php
namespace classes;
use PDOException;
use PDO;

class User {
    private $dbh;

    public function __construct($dbh) {
        $this->dbh = $dbh;}

 public function register($fullname, $email, $mobile, $password, $address, $dob, $nicImagePath, $selfieImagePath) {
    try {
        $stmt = $this->dbh->prepare("INSERT INTO tblusers (FullName, EmailId, Password, ContactNo, DOB, Address, Selfie, NIC) VALUES (:fullname, :email, :password, :contactno, :dob, :address, :selfie_image, :nic_image)");

       
        $stmt->bindParam(':fullname', $fullname);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $password);
        $stmt->bindParam(':contactno', $mobile); 
        $stmt->bindParam(':dob', $dob);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':selfie_image', $selfieImagePath);
        $stmt->bindParam(':nic_image', $nicImagePath);
        $stmt->execute();
        return true;
    } catch (PDOException $e) {
        error_log("Error in register method: " . $e->getMessage());
        return false;
    }
}

     public function getAllUsers() {
        $sql = "SELECT * FROM tblusers";
        $query = $this->dbh->prepare($sql);
        $query->execute();
        return $query->fetchAll(PDO::FETCH_OBJ);
    }
   }



        
        
        

