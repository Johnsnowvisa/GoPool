<?php
namespace classes;

use PDO;

class VehicleDetails {
    private $dbh;

    public function __construct($dbh) {
        $this->dbh = $dbh;
    }

    public function getVehicleDetails($vhid) {
        $sql = "SELECT tblvehicles.*, tblbrands.BrandName, tblbrands.id as bid 
                FROM tblvehicles 
                JOIN tblbrands ON tblbrands.id = tblvehicles.VehiclesBrand 
                WHERE tblvehicles.id = :vhid";
        $query = $this->dbh->prepare($sql);
        $query->bindParam(':vhid', $vhid, PDO::PARAM_INT);
        $query->execute();
        return $query->fetchAll(PDO::FETCH_OBJ);
    }

    public function displayVehicleDetails($vhid) {
        $results = $this->getVehicleDetails($vhid);
        if (count($results) > 0) {
            foreach ($results as $result) {
                $_SESSION['brndid'] = $result->bid;
                // Display the details as needed
                echo "<h2>" . htmlentities($result->BrandName) . " " . htmlentities($result->VehicleName) . "</h2>";
                echo "<p>Price: " . htmlentities($result->PricePerDay) . "</p>";
                echo "<p>Model Year: " . htmlentities($result->ModelYear) . "</p>";
                // Add more fields as necessary
            }
        } else {
            echo "<p>No vehicle found.</p>";
        }
    }
}




