<?php
namespace classes;

use PDO;

class VehicleDAO {
    private $dbh;

    public function __construct(PDO $dbh) {
        $this->dbh = $dbh;
    }

    public function getVehicles($limit = 15) {
        $sql = "SELECT tblvehicles.VehiclesTitle, tblbrands.BrandName, tblvehicles.PricePerDay, tblvehicles.FuelType, tblvehicles.ModelYear, tblvehicles.id, tblvehicles.SeatingCapacity, tblvehicles.VehiclesOverview, tblvehicles.Vimage1 
                FROM tblvehicles 
                JOIN tblbrands ON tblbrands.id = tblvehicles.VehiclesBrand 
                LIMIT :limit";

        $query = $this->dbh->prepare($sql);
        $query->bindParam(':limit', $limit, PDO::PARAM_INT);

        try {
            $query->execute();
        } catch (PDOException $e) {
            echo "Query failed: " . $e->getMessage();
            return [];
        }

        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
}
